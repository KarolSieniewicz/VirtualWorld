public class PodgladOrganizmow {
    Organizm aktualnyOrganizm;
    PodgladOrganizmow next;
    PodgladOrganizmow() {
        
    }
}
